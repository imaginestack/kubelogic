```bash
mkdir go-workspace
export GOPATH=$PWD/go-workspace
go mod download
go run main.go
```
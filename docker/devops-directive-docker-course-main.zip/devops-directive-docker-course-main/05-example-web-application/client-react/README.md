```
npm create vite@latest
```

```
nvm ls
nvm use node 19.4
npm install
npm run dev
```

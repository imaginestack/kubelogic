MariaDB
=======

This role builds and maintains a single or multiple-instance MariaDB database cluster inside of Kubernetes.

Requirements
------------

TODO.

Role Variables
--------------

TODO.

Dependencies
------------

N/A

Example Playbook
----------------

    - hosts: localhost
      connection: local
      roles:
         - mariadb

License
-------

MIT / BSD

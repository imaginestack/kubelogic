// +k8s:deepcopy-gen=package

// Package v1 is the v1 version of the API.
// +groupName=moodlecontroller.kubeplus
package v1

package moodlecontroller

const (
	GroupName = "moodlecontroller.kubeplus"
)

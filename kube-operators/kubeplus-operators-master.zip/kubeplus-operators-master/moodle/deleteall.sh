#!/bin/bash

kubectl delete moodles moodle1
kubectl delete pv moodle1
kubectl delete pvc moodle1

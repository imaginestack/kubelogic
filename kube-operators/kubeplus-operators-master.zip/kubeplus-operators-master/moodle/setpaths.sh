#!/bin/bash

export GOROOT=/usr/local/go
export PATH=/usr/local/go/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin
export GOPATH=$HOME/go

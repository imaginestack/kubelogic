===================
KubePlus Operators
===================

1) Moodle

   - Check README.rst in moodle folder for details

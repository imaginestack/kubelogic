---
title: Rework webservice configuration
merge_request: 1307
author: 
type: changed

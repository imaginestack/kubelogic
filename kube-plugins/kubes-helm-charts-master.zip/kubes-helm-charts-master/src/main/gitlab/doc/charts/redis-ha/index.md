---
redirect_to: '../../installation/deployment.md#redis'
---

NOTE: **Note:**
The Redis HA chart was removed in the `3.0` release of the GitLab Helm chart. Please
refer to an older edition of the documentation if you need access to it's documentation.

This document was deleted. Return to the [Redis deployment documentation](../../installation/deployment.md#redis).

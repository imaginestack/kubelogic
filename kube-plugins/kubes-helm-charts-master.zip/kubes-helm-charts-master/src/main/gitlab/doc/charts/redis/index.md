---
redirect_to: '../../installation/deployment.md#redis'
---

NOTE: **Note:**
Our fork of the Redis chart was switched in the `3.0` release of the GitLab
Helm chart to use the [upstream Redis chart](https://github.com/bitnami/charts/tree/master/bitnami/redis).
Please refer to an older version of the docs if you are looking for the documentation
for our older fork.

This document was deleted. Return to the [Redis deployment documentation](../../installation/deployment.md#redis).

---
stage: Enablement
group: Distribution
info: To determine the technical writer assigned to the Stage/Group associated with this page, see https://about.gitlab.com/handbook/engineering/ux/technical-writing/#designated-technical-writers
---

# Release

- [4.0](4_0.md)
- [3.0](3_0.md)
- [2.0](2_0.md)
- [1.0](1_0.md)
- [Beta](beta.md)
- [Alpha](alpha.md)

# sidecar-ipsec
Sidecar container to deploy IPSec in Kubernetes

**Work in Progress**

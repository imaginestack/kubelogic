# Packer Build - Debian 11 minimal Vagrant Box

**Current Debian Version Used**: 11.2.0

See the [project README.md](../README.md) for usage instructions.

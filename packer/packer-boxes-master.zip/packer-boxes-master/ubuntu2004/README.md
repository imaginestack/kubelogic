# Packer Build - Ubuntu 20.04 minimal Vagrant Box

**Current Ubuntu Version Used**: 20.04.1 Legacy server install image

See the [project README.md](../README.md) for usage instructions.

# Packer Build - Ubuntu 18.04 minimal Vagrant Box

**Current Ubuntu Version Used**: 18.04.5

See the [project README.md](../README.md) for usage instructions.

# Packer Build - Debian 10 minimal Vagrant Box

**Current Debian Version Used**: 10.11.0

See the [project README.md](../README.md) for usage instructions.

# Packer Example - Debian 9 minimal Vagrant Box

**Current Debian Version Used**: 9.13.0

See the [project README.md](../README.md) for usage instructions.

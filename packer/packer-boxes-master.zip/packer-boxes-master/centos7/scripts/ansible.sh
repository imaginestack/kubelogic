#!/bin/bash -eux

# Install EPEL.
yum -y install epel-release

# Install Ansible.
yum -y install ansible

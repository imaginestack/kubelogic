# Packer Build - CentOS 7 minimal Vagrant Box

**Current CentOS Version Used**: 7.9 (2009)

See the [project README.md](../README.md) for usage instructions.

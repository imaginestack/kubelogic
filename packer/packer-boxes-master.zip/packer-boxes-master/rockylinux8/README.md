# Packer Build - Rocky Linux 8 minimal Vagrant Box

**Current Rocky Linux Version Used**: 8.5

See the [project README.md](../README.md) for usage instructions.
